# Architecture
AsyncStorage stores students, attendance, exams, fees, homework, messages,
announcements and a syncQueue. Every local write also creates a syncQueue item.
A future API worker can upload queue items and resolve conflicts.

Suggested production stack: PostgreSQL + REST/GraphQL, JWT/OAuth, object storage
for photos/PDFs, Expo Notifications/FCM/APNs, and a payment-provider adapter.
