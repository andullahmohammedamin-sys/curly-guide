# Fulunt Zone
Offline-first Expo/React Native school management app.

Included: Admin/Teacher/Student demo login, local offline storage, dashboards,
student admission, QR student IDs, QR attendance, exams/report cards, fees,
homework, messaging, announcements, and a sync queue.

Demo accounts:
- admin / admin123
- teacher / teacher123
- student / student123

Run:
1. Install Node.js.
2. Extract this folder.
3. Run `npm install`.
4. Run `npx expo start`.
5. Open with Expo Go or an Android/iOS simulator.

Demo authentication is NOT production security. A production release needs a real
backend, password hashing, secure sessions, server authorization, encrypted
sensitive storage, push infrastructure, payment integration, and sync conflict handling.
